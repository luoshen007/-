// 检查单个网站状态
function checkWebsiteStatus(card) {
    const url = card.getAttribute('data-url');
    const statusElement = card.querySelector('.website-status');

    fetch(url, { method: 'HEAD', mode: 'no-cors' })
        .then(response => {
            if (response.ok || response.status === 0) {
                statusElement.innerHTML = '<i class="fas fa-check-circle"></i> 在线';
                statusElement.classList.add('success');
            } else {
                statusElement.innerHTML = '<i class="fas fa-times-circle"></i> 离线';
                statusElement.classList.add('error');
            }
        })
        .catch(() => {
            statusElement.innerHTML = '<i class="fas fa-times-circle"></i> 离线';
            statusElement.classList.add('error');
        });
}

// 初始化默认网站状态检查
function initDefaultWebsites() {
    const websiteCards = document.querySelectorAll('.website-card');
    websiteCards.forEach(card => {
        checkWebsiteStatus(card);

        // 添加点击事件
        card.addEventListener('click', () => {
            const url = card.getAttribute('data-url');
            window.open(url, '_blank'); // 在新标签页打开
        });
    });
}

// 页面加载时初始化
document.addEventListener('DOMContentLoaded', initDefaultWebsites);

// 搜索功能
document.getElementById('searchButton').addEventListener('click', function () {
    const query = document.getElementById('searchInput').value.trim();
    const statusMessage = document.getElementById('statusMessage');

    if (!query) {
        statusMessage.innerHTML = '<i class="fas fa-exclamation-circle"></i> 请输入搜索内容。';
        statusMessage.className = 'status-message error';
        return;
    }

    // 跳转到必应搜索
    const searchUrl = `https://www.bing.com/search?q=${encodeURIComponent(query)}`;
    window.open(searchUrl, '_blank');
});