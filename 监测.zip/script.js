
// 默认网站数据
const defaultWebsites = [
    {
        name: "洛神之世",
        url: "https://link3.cc/luoshen007",
        image: "https://api.r10086.com/樱道随机图片api接口.php?自适应图片系列=原神"
    },
    {
        name: "GitHub",
        url: "https://www.github.com",
        image: "https://api.r10086.com/PPT/PPT.php?PPT=原神&参数=雪花特效"
    },
    {
        name: "Baidu",
        url: "https://www.baidu.com",
        image: "https://api.r10086.com/PPT/PPT.php?PPT=原神"
    },
    {
        name: "知乎",
        url: "https://www.zhihu.com",
        image: "https://api.r10086.com/樱道随机图片api接口.php?图片系列=动漫综合3"
    },
    {
        name: "Bing",
        url: "https://www.bing.com",
        image: "https://api.r10086.com/樱道随机图片api接口.php?图片系列=动漫综合1"
    }
];

// 从本地存储加载网站数据
function loadWebsites() {
    let websites = JSON.parse(localStorage.getItem('websites'));


    // 如果本地存储中没有数据，则初始化默认数据
    if (!websites || websites.length === 0) {
        websites = defaultWebsites;
        saveWebsites(websites); // 保存默认数据到本地存储
    }

    const cardContainer = document.getElementById('card-container');
    cardContainer.innerHTML = ''; // 清空容器

    websites.forEach((website, index) => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.backgroundImage = `url('${website.image || 'https://via.placeholder.com/300'}')`;
        card.innerHTML = `
            <h2>${website.name}</h2>
            <p>${website.url}</p>
            <button onclick="checkWebsite('${website.url}', this)">检查状态</button>
            <p class="status">检查中...</p>
            <button class="delete-button" onclick="deleteWebsite(${index})">删除</button>
        `;
        cardContainer.appendChild(card);
    });

    // 页面加载后自动检查所有网站状态
    autoCheckAllWebsites();
}

// 自动检查所有网站状态
function autoCheckAllWebsites() {
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        const url = card.querySelector('p').textContent;
        const button = card.querySelector('button');
        checkWebsite(url, button);
    });
}

// 保存网站数据到本地存储
function saveWebsites(websites) {
    localStorage.setItem('websites', JSON.stringify(websites));
}
// 添加网站
function addWebsite() {
    const name = document.getElementById('site-name').value;
    const url = document.getElementById('site-url').value;
    const image = document.getElementById('site-image').value;

    if (name && url) {
        const websites = JSON.parse(loalStorage.getItem('websites')) || [];
        websites.push({ name, url, image });
        saveWebsites(websites); // 保存到本地存储
        loadWebsites(); // 重新加载卡片
        closeAdminPanel();
    } else {
        alert('请填写网站名称和URL！');
    }
}

// 删除网站
function deleteWebsite(index) {
    const websites = JSON.parse(localStorage.getItem('websites')) || [];
    websites.splice(index, 1); // 删除指定索引的网站
    saveWebsites(websites); // 保存更新后的数据
    loadWebsites(); // 重新加载卡片
}

// 检查网站状态
function checkWebsite(url, button) {
    const statusElement = button.parentElement.querySelector('.status');
    statusElement.textContent = '检查中...';
    statusElement.style.color = '#ffcc00';

    fetch(url)
        .then(response => {
            if (response.ok) {
                statusElement.textContent = '在线';
                statusElement.style.color = '#4CAF50'; // 绿色
            } else {
                statusElement.textContent = '离线';
                statusElement.style.color = '#FF5252'; // 红色
            }
        })
        .catch(() => {
            statusElement.textContent = '离线';
            statusElement.style.color = '#FF5252'; // 红色
        });
}

// 打开后台管理面板
function openAdminPanel() {
    document.getElementById('admin-modal').style.display = 'flex';
}

// 关闭后台管理面板
function closeAdminPanel() {
    document.getElementById('admin-modal').style.display = 'none';
}

// 页面加载时加载网站数据并自动检查状态
window.onload = loadWebsites;

